<!--

DO NOT SUBMIT ISSUES ASKING TO REMOVE ES6.

IT WILL BE CLOSED.
IT WILL BE LOCKED.

We use ES2015+ for a reason. Modern best
practices dictate the use of tooling like
Babel and @babel/preset-env in order to
target the browsers that make sense for
your project.

For more information, please see:
https://github.com/sindresorhus/ama/issues/446#issuecomment-281014491

Please keep in mind that `debug` is downloaded,
installed, transpiled and used millions of times
*per day*. If you have an error with `debug`, it's
most likely your own configuration (e.g. with Babel,
Webpack, etc).

Unless you post ample evidence you have tried
to fix this yourself, it will most likely
be determined that your issue is localized
to your project - not `debug`.

-->
